import express from 'express';
import createPlayer from '../Controller/createPlayer.js';
import deletePlayer from '../Controller/deletePlayer.js';
import getPlayerById from '../Controller/getPlayerById.js';
import readAllPlayersData from '../Controller/readAllPlayersData.js';
import getAllPlayersByRank from '../Controller/getAllPlayersByRank.js';
import getAllPlayersByGender from '../Controller/getAllPlayersByGender.js';
import getAllPlayersByRace from '../Controller/getAllPlayersByRace.js';
import getPlayerItems from '../Controller/getPlayerItems.js';
import getPlayerBalance from '../Controller/getPlayerBalance.js';
import getPlayerLoginDays from '../Controller/getPlayerLoginDays.js';
import updateDataPlayer from '../Controller/updateDataPlayer.js';

const router = express.Router();

router.post('/create-player', createPlayer);
router.get('/player/:id', getPlayerById);
router.get('/players', readAllPlayersData);
router.get('/players/rank', getAllPlayersByRank);
router.get('/players/gender/:gender', getAllPlayersByGender);
router.get('/players/race/:race', getAllPlayersByRace);
router.get('/player/items/:id', getPlayerItems);
router.get('/player/balance/:id', getPlayerBalance);
router.get('/player/login-days/:id', getPlayerLoginDays);
router.put('/player/:id', updateDataPlayer);
router.delete('/player/:id', deletePlayer);

export default router;
