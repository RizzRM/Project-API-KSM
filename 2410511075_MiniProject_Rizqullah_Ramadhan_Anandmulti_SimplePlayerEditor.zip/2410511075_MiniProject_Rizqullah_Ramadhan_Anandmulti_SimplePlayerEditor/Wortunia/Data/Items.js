export default [
        "Small Sword", "Large Sword", "Bow", "Armor", "Shield", 
        "Potion", "Helmet", "Ring", "Boots", "Gloves",
        "Necklace", "Health Potion", "Magic Wand", "Fire Staff",
        "Ice Staff", "Angel's Grace Helmet", "Super Speed Boots", "Revival Potion",
        "Aegis Shield", "Al Maajik Bloom", "Al Maajik Gold", "Al Maajik Memento",
        "Beast Tail", "Beastly Armour", "Beastly Boots", "Beastly Cap", "Beastly Gauntlets", "Beastly Leggings", "Beastly Necklace",
        "Beaver Beam", "Beef",   "Surf's Up Shorts", "Suspicious Object", "Swallow Tail", "Sweet Fish Pastry", "Sweet Potato", "Sweet Potato Dessert", "Sweetcorn",
        "Swimming Ring", "Sword of Heroes", "Swordfish",
    ];