import fs from 'fs';
import path from 'path';

const dbFilePath = path.join(process.cwd(), 'Data', 'Player.json');

function writeDatabase(data) {
    fs.writeFileSync(dbFilePath, JSON.stringify(data, null, 2));
}

function getLoginBonus(day) {
    const rewards = [
        "Armor Upgrade",
        "Big Sword",
        "Great Shield",
        "Health Potion",
        "Angel's Grace Helmet",
        "Super Speed Boots",
        "Revival Potion"
    ];
    return rewards[day - 1] || null;
}

export default (req, res) => {
    const playerId = req.params.id;
    const { items, removeItems, level, balance, loginDays } = req.body;
    const players = JSON.parse(fs.readFileSync(dbFilePath, 'utf-8') || '[]');
    const player = players.find(p => p.id === playerId);

    if (!player) return res.status(404).json({ message: 'Player not found.' });

    if (Array.isArray(items)) {
        const remainingSpace = 20 - player.items.length;
        player.items.push(...items.slice(0, remainingSpace));
    }

    if (Array.isArray(removeItems)) {
        player.items = player.items.filter(item => !removeItems.includes(item));
    }

    if (typeof level === 'number') player.level += level;
    if (typeof balance === 'number') player.balance += balance;

    if (typeof loginDays === 'number') {
        player.loginDays = loginDays;

        if (!player.claimedRewards) player.claimedRewards = Array(7).fill(false);
        if (!player.loginRewards) player.loginRewards = [];

        const addItem = (item) => {
            if (player.items.length < 20 && !player.items.includes(item)) {
                player.items.push(item);
            }
        };

        if (loginDays >= 7) {
            for (let day = 1; day <= 7; day++) {
                const bonusItem = getLoginBonus(day);
                if (bonusItem && !player.claimedRewards[day - 1]) {
                    player.claimedRewards[day - 1] = true;
                    player.loginRewards.push(bonusItem);
                    addItem(bonusItem);
                }
            }
        } else {
            for (let day = 1; day <= loginDays; day++) {
                const bonusItem = getLoginBonus(day);
                if (bonusItem && !player.claimedRewards[day - 1]) {
                    player.claimedRewards[day - 1] = true;
                    player.loginRewards.push(bonusItem);
                    addItem(bonusItem);
                }
            }
        }

        player.loginRewards = [...new Set(player.loginRewards)];
    }

    writeDatabase(players);
    res.status(200).json(player);
};
