import fs from 'fs';
import path from 'path';

const dbFilePath = path.join(process.cwd(), 'Data', 'Player.json');

export default (req, res) => {
    const { gender } = req.params;
    const players = JSON.parse(fs.readFileSync(dbFilePath, 'utf-8') || '[]');

    const filteredPlayers = players.filter(p => p.gender.toLowerCase() === gender.toLowerCase());

    res.status(200).json(filteredPlayers.map(({ name, level, race }) => ({ name, level, race })));
};
