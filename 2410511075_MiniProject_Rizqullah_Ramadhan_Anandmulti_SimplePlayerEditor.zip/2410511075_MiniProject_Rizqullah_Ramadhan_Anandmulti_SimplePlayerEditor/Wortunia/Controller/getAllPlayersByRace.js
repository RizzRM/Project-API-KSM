import fs from 'fs';
import path from 'path';

const dbFilePath = path.join(process.cwd(), 'Data', 'Player.json');

export default (req, res) => {
    const { race } = req.params;
    const players = JSON.parse(fs.readFileSync(dbFilePath, 'utf-8') || '[]');

    const filteredPlayers = players.filter(p => p.race.toLowerCase() === race.toLowerCase());

    res.status(200).json(filteredPlayers.map(({ name, level, gender }) => ({ name, level, gender })));
};
