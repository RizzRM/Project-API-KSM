import fs from 'fs';
import path from 'path';

const dbFilePath = path.join(process.cwd(), 'Data', 'Player.json');

function writeDatabase(data) {
    fs.writeFileSync(dbFilePath, JSON.stringify(data, null, 2));
}

export default (req, res) => {
    const playerId = req.params.id;
    let players = JSON.parse(fs.readFileSync(dbFilePath, 'utf-8') || '[]');
    const playerIndex = players.findIndex(p => p.id === playerId);

    if (playerIndex === -1) return res.status(404).json({ message: 'Player not found.' });

    players.splice(playerIndex, 1);
    writeDatabase(players);
    res.status(200).json({ message: 'Player deleted successfully.' });
};
