import fs from 'fs';
import path from 'path';

const dbFilePath = path.join(process.cwd(), 'Data', 'Player.json');

export default (req, res) => {
    const players = JSON.parse(fs.readFileSync(dbFilePath, 'utf-8') || '[]');
    res.status(200).json(players);
};
