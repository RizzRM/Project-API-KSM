import fs from 'fs';
import path from 'path';
import items from '../Data/Items.js';

const dbFilePath = path.join(process.cwd(), 'Data', 'Player.json');

function writeDatabase(data) {
    fs.writeFileSync(dbFilePath, JSON.stringify(data, null, 2));
}

function getRandomItems(count) {
    const shuffledItems = items.sort(() => 0.5 - Math.random());
    return shuffledItems.slice(0, count);
}

function generatePlayerId() {
    return Math.random().toString(36).substring(2, 7);
}

function getLoginRewards(day) {
    const rewards = {
        1: ["Armor Upgrade"],
        2: ["Big Sword"],
        3: ["Great Shield"],
        4: ["Health Potion", "Health Potion", "Health Potion", "Health Potion", "Health Potion"],
        5: ["Angel's Grace Helmet"],
        6: ["Super Speed Boots"],
        7: ["Revival Potion"]
    };
    return rewards[day] || [];
}

export default (req, res) => {
    const { name, race, gender } = req.body;

    if (!name || !race || !gender) {
        return res.status(400).json({ error: 'Name, race, and gender are required.' });
    }

    let loginRewards = getLoginRewards(1);
    loginRewards = [...new Set(loginRewards)];
    const items = [...getRandomItems(5), ...loginRewards]; 

    const newPlayer = {
        id: generatePlayerId(),
        name,
        level: 1,
        race,
        gender,
        items,
        loginDays: 1,
        claimedRewards: [true, ...Array(6).fill(false)],
        balance: 0,
        loginRewards
    };

    let players = [];
    try {
        if (fs.existsSync(dbFilePath)) {
            const fileData = fs.readFileSync(dbFilePath, 'utf-8');
            players = fileData ? JSON.parse(fileData) : [];
        }
    } catch (error) {
        console.error("Error reading database:", error);
        return res.status(500).json({ error: 'Internal Server Error' });
    }

    players.push(newPlayer);

    try {
        writeDatabase(players);
        res.status(201).json(newPlayer);
    } catch (error) {
        console.error("Error writing to database:", error);
        res.status(500).json({ error: 'Failed to create player' });
    }
};
