import fs from 'fs';
import path from 'path';

const dbFilePath = path.join(process.cwd(), 'Data', 'Player.json');

export default (req, res) => {
    const playerId = req.params.id;
    const players = JSON.parse(fs.readFileSync(dbFilePath, 'utf-8') || '[]');
    const player = players.find(p => p.id === playerId);

    if (!player) return res.status(404).json({ message: 'Player not found.' });

    res.status(200).json({
        name: player.name,
        level: player.level,
        race: player.race,
        items: player.items
    });
};
